from django.contrib import admin
from .models import WriteBlog


admin.site.register(WriteBlog)
