from django.db import models
import datetime
from django.contrib.auth.models import User


class WriteBlog(models.Model):
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    description = models.CharField(max_length=1000)
    image = models.ImageField(blank=True, null=True, upload_to="images/")
    type = models.CharField(default="", max_length=20)
    blog_date = models.DateField("Date", default=datetime.date.today)

    def __str__(self):
        return self.name
