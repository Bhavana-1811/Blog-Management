from django.shortcuts import render, HttpResponse
from .models import WriteBlog
from django.contrib.auth.models import User
import random
import operator
from django.contrib.auth import login as auth_login
from django.contrib.auth import authenticate
from django.contrib.auth import logout


def captcha(request):
    op_mappings = {"+": operator.add,
                   "-": operator.sub,
                   "*": operator.mul}

    op = random.choice(["+", "-", "*"])

    number1 = random.randint(1, 9)
    number2 = random.randint(1, 10)

    answer = op_mappings[op](number1, number2)
    op_str = (number1, str(op), number2, '=', '?')
    return op_str, answer


def firstpage(request):
    return render(request, template_name='login.html')


def login(request):
    data = request.POST
    output, result = captcha(request)
    op = str(output[0]) + ' ' + output[1] + ' ' + str(output[2]) + ' ' + output[3] + ' ' + output[4]
    if not data:
        return render(request, template_name='register.html', context={'op': op, 'result': result})
    user_data = authenticate(username=data['uname'], password=data['psw'])
    if user_data:
        user_blogs = WriteBlog.objects.filter(user_id=user_data)
        auth_login(request, user_data)
        return render(request, template_name='home.html', context={'blogs': user_blogs})
    return render(request, template_name='login.html', context={'msg': 'Invalid credentials'})


def register(request):
    data = request.POST
    users = User.objects.filter(username=data['uname'])
    output, result = captcha(request)
    op = str(output[0]) + ' ' + output[1] + ' ' + str(output[2]) + ' ' + output[3] + ' ' + output[4]
    if not users:
        a = User.objects.create_user(username=data['uname'], password=data['psw'])
        a.save()
        return render(request, 'login.html', context={'msg': 'Registration Successful'})
    return render(request, 'register.html', context={'msg': 'Username already taken', 'op': op, 'result': result})


def homepage(request):
    user_blogs = WriteBlog.objects.filter(user_id=request.user)
    return render(request, template_name='home.html', context={'blogs': user_blogs})


def add_new_blog(request):
    return render(request, template_name='writeblog.html')


def searchpage(request):
    return render(request, template_name='search.html')


def log_out(request):
    logout(request)
    return render(request, 'login.html')


def write_blogs(request):
    print('dusra function')
    data = request.POST
    print(data, 'haa isme aaya h')
    print(request.FILES.get('image'))
    current_user = request.user
    a = WriteBlog(user_id=current_user, name=data['name'], image=request.FILES.get('image'), description=data['description'], type=data['type'])
    a.save()
    return render(request, template_name='writeblog.html', context={'msg': 'Blog Created Successfully!!!'})


def search_users(request):
    data = request.POST
    users = User.objects.filter(username=data['search'])
    if users:
        users_blogs = WriteBlog.objects.filter(user_id=users[0].id, type='public')
        if users_blogs:
            return render(request, template_name='search.html', context={'blogs': users_blogs})
        return render(request, template_name='search.html', context={'msg': 'No Blog Found!!!'})
    return render(request, template_name='search.html', context={'msg': 'No User Found!!!'})




