"""ATG_Blog URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from Blog import views as b
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', b.firstpage, name='firstpage'),
    path('login', b.login, name='login'),
    path('register', b.register, name='register'),
    path('write_blogs', b.write_blogs, name='write_blogs'),
    path('search_users', b.search_users, name='search_users'),
    path('homepage', b.homepage, name='homepage'),
    path('add_new_blog', b.add_new_blog, name='add_new_blog'),
    path('searchpage', b.searchpage, name='searchpage'),
    path('logout', b.log_out, name='logout'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

